"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence, useInView } from "framer-motion";
import { useAppStore, type ComponentItem } from "@/lib/store";
import {
  Sparkles, Layers, Zap, Palette, Search, Menu, X,
  ArrowRight, ChevronDown, Star, Code2, Box, MousePointerClick,
  Mail, Check, Crown, Rocket, Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

/* ──────────────────────────── ANIMATION VARIANTS ──────────────────────────── */

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.2 },
  },
};

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: "spring", stiffness: 300, damping: 24 },
  },
};

const scaleIn = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { opacity: 1, scale: 1, transition: { type: "spring", stiffness: 200, damping: 20 } },
};

const slideInLeft = {
  hidden: { opacity: 0, x: -40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

const slideInRight = {
  hidden: { opacity: 0, x: 40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

/* ──────────────────────────── FLOATING PARTICLES ──────────────────────────── */

function FloatingParticles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-white/10"
          style={{
            width: Math.random() * 6 + 2,
            height: Math.random() * 6 + 2,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -30, 0],
            x: [0, Math.random() * 20 - 10, 0],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: Math.random() * 4 + 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: Math.random() * 2,
          }}
        />
      ))}
    </div>
  );
}

/* ──────────────────────────── ANIMATED COUNTER ──────────────────────────── */

function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    let start = 0;
    const duration = 2000;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [isInView, target]);

  return (
    <span ref={ref} className="tabular-nums">
      {count.toLocaleString()}{suffix}
    </span>
  );
}

/* ──────────────────────────── NAVBAR ──────────────────────────── */

function Navbar() {
  const { mobileMenuOpen, setMobileMenuOpen } = useAppStore();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { label: "Features", href: "#features" },
    { label: "Components", href: "#components" },
    { label: "Skills", href: "#skills" },
    { label: "Pricing", href: "#pricing" },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 200, damping: 25 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-lg bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
              SkillForge
            </span>
          </motion.div>

          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <motion.a
                key={link.label}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-zinc-600 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-white rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                whileHover={{ y: -1 }}
                whileTap={{ scale: 0.97 }}
              >
                {link.label}
              </motion.a>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                size="sm"
                className="hidden sm:flex bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 shadow-lg shadow-amber-500/25"
              >
                Get Started
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </motion.div>

            <motion.button
              whileTap={{ scale: 0.9 }}
              className="md:hidden p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </motion.button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl border-t border-zinc-200 dark:border-zinc-800"
          >
            <div className="px-4 py-3 space-y-1">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="block px-4 py-3 text-base font-medium text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <Button className="w-full mt-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white border-0">
                Get Started
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}

/* ──────────────────────────── HERO ──────────────────────────── */

function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-900" />
      <div className="absolute inset-0 bg-gradient-to-t from-amber-500/5 via-transparent to-orange-500/5" />
      <FloatingParticles />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center pt-20 pb-12">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
          className="space-y-6"
        >
          <motion.div variants={staggerItem}>
            <Badge
              variant="secondary"
              className="bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20 px-4 py-1.5 text-sm"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              Powered by SMP v5.1 Protocol
            </Badge>
          </motion.div>

          <motion.h1
            variants={staggerItem}
            className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight"
          >
            <span className="text-white">Build with</span>
            <br />
            <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-red-400 bg-clip-text text-transparent">
              Agent Skills
            </span>
          </motion.h1>

          <motion.p
            variants={staggerItem}
            className="text-lg sm:text-xl text-zinc-400 max-w-2xl mx-auto leading-relaxed"
          >
            Discover, compose, and deploy AI agent skills with Framer Motion animations,
            21st.dev crafted components, and mobile-first design. Your workflow, unified.
          </motion.p>

          <motion.div
            variants={staggerItem}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                size="lg"
                className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white border-0 shadow-2xl shadow-amber-500/25 px-8 text-base"
              >
                <Rocket className="w-5 h-5 mr-2" />
                Explore Skills
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              <Button
                size="lg"
                variant="outline"
                className="border-zinc-600 text-zinc-300 hover:bg-zinc-800 hover:text-white px-8 text-base"
              >
                <Code2 className="w-5 h-5 mr-2" />
                View Components
              </Button>
            </motion.div>
          </motion.div>

          <motion.div
            variants={staggerItem}
            className="flex items-center justify-center gap-6 pt-6 text-sm text-zinc-500"
          >
            <div className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-400" />
              Mobile-First
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-400" />
              Framer Motion
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-400" />
              21st.dev
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <ChevronDown className="w-6 h-6 text-zinc-500" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────── STATS ──────────────────────────── */

function Stats() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    { value: 100, suffix: "+", label: "Agent Skills", icon: Layers },
    { value: 50, suffix: "+", label: "UI Components", icon: Box },
    { value: 99, suffix: "%", label: "Mobile Ready", icon: MousePointerClick },
    { value: 10, suffix: "x", label: "Faster Dev", icon: Zap },
  ];

  return (
    <section ref={ref} className="py-16 sm:py-20 bg-zinc-50 dark:bg-zinc-900/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6"
        >
          {stats.map((stat) => (
            <motion.div
              key={stat.label}
              variants={staggerItem}
              whileHover={{ y: -4, scale: 1.02 }}
              className="text-center p-6 rounded-2xl bg-white dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-700/50 shadow-sm"
            >
              <stat.icon className="w-6 h-6 mx-auto mb-3 text-amber-500" />
              <div className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                <AnimatedCounter target={stat.value} suffix={stat.suffix} />
              </div>
              <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">{stat.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────── FEATURES ──────────────────────────── */

function Features() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const features = [
    {
      icon: Sparkles,
      title: "Framer Motion Animations",
      description:
        "Smooth page transitions, staggered reveals, gesture-driven interactions, and scroll-triggered animations that make your UI feel alive and responsive.",
      color: "from-amber-500 to-orange-500",
    },
    {
      icon: Palette,
      title: "21st.dev Components",
      description:
        "Hand-crafted React components from the 21st.dev registry. No generic AI slop — every component is designed with taste, built for production use.",
      color: "from-emerald-500 to-teal-500",
    },
    {
      icon: Layers,
      title: "UI/UX Pro Max",
      description:
        "Mobile-first responsive design with proper touch targets, semantic HTML, ARIA accessibility, keyboard navigation, and dark mode support out of the box.",
      color: "from-violet-500 to-purple-500",
    },
    {
      icon: Zap,
      title: "21st Builder v2",
      description:
        "Component composition and building patterns that let you assemble complex interfaces from simple, reusable building blocks with type safety.",
      color: "from-rose-500 to-pink-500",
    },
    {
      icon: Shield,
      title: "SMP v5.1 Protocol",
      description:
        "Orchestrated workflow with quality gates at every stage: discovery, brainstorming, research, planning, execution, validation, and review.",
      color: "from-sky-500 to-cyan-500",
    },
    {
      icon: Code2,
      title: "find-skills CLI",
      description:
        "Discover and install agent skills from the open ecosystem. Version-locked toolsets, quality verification, and one-command installation.",
      color: "from-indigo-500 to-blue-500",
    },
  ];

  return (
    <section id="features" ref={ref} className="py-20 sm:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 sm:mb-16"
        >
          <Badge variant="secondary" className="mb-4 bg-amber-500/10 text-amber-600 border-amber-500/20">
            Features
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold text-zinc-900 dark:text-white">
            Everything You Need
          </h2>
          <p className="mt-4 text-lg text-zinc-500 dark:text-zinc-400 max-w-2xl mx-auto">
            Six specialized agent skills working in concert to deliver production-ready,
            beautifully animated, mobile-first web applications.
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6"
        >
          {features.map((feature) => (
            <motion.div key={feature.title} variants={staggerItem} whileHover={{ y: -6 }}>
              <Card className="h-full border-zinc-200 dark:border-zinc-700/50 hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-3 shadow-lg`}
                  >
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────── COMPONENT BROWSER ──────────────────────────── */

function ComponentBrowser() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const { components, setComponents, searchQuery, setSearchQuery, selectedCategory, setSelectedCategory } = useAppStore();
  const [loading, setLoading] = useState(true);

  const categories = ["all", "hero", "features", "stats", "social-proof", "pricing", "cta", "navigation"];

  useEffect(() => {
    async function fetchComponents() {
      try {
        const res = await fetch("/api/components");
        const data = await res.json();
        const items = data.components || [];
        setComponents(items);
      } catch {
        setComponents([]);
      } finally {
        setLoading(false);
      }
    }
    fetchComponents();
  }, [setComponents]);

  const filtered = components.filter((c: ComponentItem) => {
    const matchSearch =
      !searchQuery ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchCategory = selectedCategory === "all" || c.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  return (
    <section id="components" ref={ref} className="py-20 sm:py-28 bg-zinc-50 dark:bg-zinc-900/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <Badge variant="secondary" className="mb-4 bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
            21st.dev Registry
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold text-zinc-900 dark:text-white">
            Component Browser
          </h2>
          <p className="mt-4 text-lg text-zinc-500 dark:text-zinc-400 max-w-2xl mx-auto">
            Browse and search crafted React components from the 21st.dev ecosystem.
            Every component is hand-crafted, not AI slop.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <div className="relative max-w-md mx-auto mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <Input
              placeholder="Search components..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700"
            />
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <motion.button
                key={cat}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-sm font-medium rounded-full transition-colors ${
                  selectedCategory === cat
                    ? "bg-amber-500 text-white shadow-md shadow-amber-500/25"
                    : "bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-700 border border-zinc-200 dark:border-zinc-700"
                }`}
              >
                {cat.charAt(0).toUpperCase() + cat.slice(1).replace("-", " ")}
              </motion.button>
            ))}
          </div>
        </motion.div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-48 rounded-2xl bg-zinc-200 dark:bg-zinc-800 animate-pulse" />
            ))}
          </div>
        ) : (
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6"
          >
            {filtered.map((comp: ComponentItem) => (
              <motion.div key={comp.id} variants={staggerItem} whileHover={{ y: -4, scale: 1.01 }}>
                <Card className="h-full border-zinc-200 dark:border-zinc-700/50 hover:shadow-lg transition-all duration-300 group cursor-pointer">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-md">
                        <Box className="w-5 h-5 text-white" />
                      </div>
                      <Badge variant="outline" className="text-xs border-zinc-300 dark:border-zinc-600">
                        {comp.category}
                      </Badge>
                    </div>
                    <CardTitle className="text-base mt-3 group-hover:text-amber-600 transition-colors">
                      {comp.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm leading-relaxed mb-3">
                      {comp.description}
                    </CardDescription>
                    <div className="flex flex-wrap gap-1.5">
                      {comp.tags.slice(0, 3).map((tag) => (
                        <span
                          key={tag}
                          className="text-xs px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {filtered.length === 0 && !loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
            <Search className="w-12 h-12 mx-auto text-zinc-300 dark:text-zinc-600 mb-4" />
            <p className="text-zinc-500 dark:text-zinc-400">No components found. Try a different search.</p>
          </motion.div>
        )}
      </div>
    </section>
  );
}

/* ──────────────────────────── SKILLS SHOWCASE ──────────────────────────── */

function SkillsShowcase() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const skills = [
    {
      name: "framer-motion-animator",
      source: "patricio0312rev/skills",
      description: "Smooth animations, page transitions, gesture-driven interactions, and orchestrated staggered sequences.",
      installCmd: "npx skills add patricio0312rev/skills --skill framer-motion-animator",
      color: "from-amber-500 to-orange-500",
    },
    {
      name: "ui-ux-pro-max",
      source: "nextlevelbuilder/ui-ux-pro-max-skill",
      description: "Mobile-first responsive design with accessibility, touch targets, semantic HTML, and dark mode.",
      installCmd: "npx skills add nextlevelbuilder/ui-ux-pro-max-skill --skill ui-ux-pro-max",
      color: "from-emerald-500 to-teal-500",
    },
    {
      name: "21st-dev-components",
      source: "21st-dev/registry",
      description: "Hand-crafted React components from the 21st.dev registry. No AI slop — real design taste.",
      installCmd: "npx skills add 21st-dev/registry --skill 21st-dev-components",
      color: "from-violet-500 to-purple-500",
    },
    {
      name: "21st-dev-builder-v2",
      source: "trin-zenityx/21st-dev-builder-v2",
      description: "Component composition patterns for building complex interfaces from simple, type-safe building blocks.",
      installCmd: "npx skills add trin-zenityx/21st-dev-builder-v2 --skill 21st-dev-builder-v2",
      color: "from-rose-500 to-pink-500",
    },
  ];

  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <section id="skills" ref={ref} className="py-20 sm:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge variant="secondary" className="mb-4 bg-violet-500/10 text-violet-600 border-violet-500/20">
            Agent Skills
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold text-zinc-900 dark:text-white">
            Skills Powering This App
          </h2>
          <p className="mt-4 text-lg text-zinc-500 dark:text-zinc-400 max-w-2xl mx-auto">
            Each skill was discovered via find-skills, verified against the skills.sh leaderboard,
            and installed with one command. Click to copy.
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid sm:grid-cols-2 gap-4 sm:gap-6"
        >
          {skills.map((skill, idx) => (
            <motion.div key={skill.name} variants={staggerItem} whileHover={{ y: -4 }}>
              <Card className="h-full border-zinc-200 dark:border-zinc-700/50 hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-10 h-10 rounded-lg bg-gradient-to-br ${skill.color} flex items-center justify-center shadow-md shrink-0`}
                    >
                      <Code2 className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{skill.name}</CardTitle>
                      <p className="text-xs text-zinc-400 mt-0.5 font-mono">{skill.source}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <CardDescription className="text-sm leading-relaxed">
                    {skill.description}
                  </CardDescription>
                  <button
                    onClick={() => handleCopy(skill.installCmd, idx)}
                    className="w-full text-left px-3 py-2.5 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-xs font-mono text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors flex items-center justify-between gap-2"
                  >
                    <span className="truncate">{skill.installCmd}</span>
                    {copiedIdx === idx ? (
                      <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                    ) : (
                      <Box className="w-4 h-4 shrink-0 opacity-50" />
                    )}
                  </button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────── PRICING ──────────────────────────── */

function Pricing() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const plans = [
    {
      name: "Starter",
      price: "Free",
      description: "Perfect for exploring agent skills and building your first project.",
      features: ["5 component downloads/mo", "Community support", "Basic animations", "Mobile-first templates"],
      icon: Zap,
      color: "border-zinc-200 dark:border-zinc-700",
      btnClass: "border-zinc-300 dark:border-zinc-600",
    },
    {
      name: "Pro",
      price: "$29",
      description: "For serious builders who need full access to the ecosystem.",
      features: [
        "Unlimited downloads",
        "Priority support",
        "All animation presets",
        "21st.dev API access",
        "Custom skill creation",
        "Team collaboration",
      ],
      icon: Crown,
      color: "border-amber-500/50 shadow-xl shadow-amber-500/10",
      btnClass: "bg-gradient-to-r from-amber-500 to-orange-600 text-white border-0 shadow-lg shadow-amber-500/25",
      popular: true,
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For teams that need governance, security, and dedicated support.",
      features: [
        "Everything in Pro",
        "SSO & RBAC",
        "Audit logs",
        "SLA guarantee",
        "Custom integrations",
        "Dedicated CSM",
      ],
      icon: Shield,
      color: "border-zinc-200 dark:border-zinc-700",
      btnClass: "border-zinc-300 dark:border-zinc-600",
    },
  ];

  return (
    <section id="pricing" ref={ref} className="py-20 sm:py-28 bg-zinc-50 dark:bg-zinc-900/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Badge variant="secondary" className="mb-4 bg-rose-500/10 text-rose-600 border-rose-500/20">
            Pricing
          </Badge>
          <h2 className="text-3xl sm:text-4xl font-bold text-zinc-900 dark:text-white">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-lg text-zinc-500 dark:text-zinc-400 max-w-2xl mx-auto">
            Start free. Scale when you need to. No hidden fees, no surprises.
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-3 gap-4 sm:gap-6 max-w-5xl mx-auto"
        >
          {plans.map((plan) => (
            <motion.div
              key={plan.name}
              variants={staggerItem}
              whileHover={{ y: -6 }}
              className="relative"
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                  <Badge className="bg-gradient-to-r from-amber-500 to-orange-600 text-white border-0 px-3 py-1 shadow-md">
                    <Star className="w-3 h-3 mr-1" /> Most Popular
                  </Badge>
                </div>
              )}
              <Card className={`h-full ${plan.color}`}>
                <CardHeader className="text-center pb-2">
                  <plan.icon className="w-8 h-8 mx-auto mb-2 text-amber-500" />
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  <div className="mt-2">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    {plan.price !== "Free" && plan.price !== "Custom" && (
                      <span className="text-zinc-500 text-sm">/mo</span>
                    )}
                  </div>
                  <CardDescription className="mt-2">{plan.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2.5">
                    {plan.features.map((feat) => (
                      <li key={feat} className="flex items-start gap-2 text-sm text-zinc-600 dark:text-zinc-300">
                        <Check className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                        {feat}
                      </li>
                    ))}
                  </ul>
                  <motion.div whileTap={{ scale: 0.97 }} className="pt-2">
                    <Button className={`w-full ${plan.btnClass}`} variant={plan.popular ? "default" : "outline"}>
                      {plan.price === "Custom" ? "Contact Sales" : "Get Started"}
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────── CTA ──────────────────────────── */

function CTASection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section ref={ref} className="py-20 sm:py-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.6, type: "spring", stiffness: 200 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-500 via-orange-500 to-red-500 p-8 sm:p-12 text-center shadow-2xl"
        >
          <FloatingParticles />
          <div className="relative z-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Ready to Build with Agent Skills?
            </h2>
            <p className="text-lg text-white/80 max-w-xl mx-auto mb-8">
              Start with one command. Compose capabilities. Ship production-ready
              apps with animations that delight and components that perform.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                <Button
                  size="lg"
                  className="bg-white text-amber-700 hover:bg-white/90 shadow-xl px-8 text-base font-semibold"
                >
                  <Rocket className="w-5 h-5 mr-2" />
                  Start Building Free
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10 px-8 text-base"
                >
                  <Layers className="w-5 h-5 mr-2" />
                  View on GitHub
                </Button>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────── FOOTER ──────────────────────────── */

function Footer() {
  return (
    <footer className="bg-zinc-900 dark:bg-zinc-950 border-t border-zinc-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg text-white">SkillForge</span>
            </div>
            <p className="text-sm text-zinc-400 leading-relaxed">
              Building with agent skills, Framer Motion, and 21st.dev components.
              Powered by the SMP v5.1 protocol.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-3">Product</h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
              <li><a href="#components" className="hover:text-white transition-colors">Components</a></li>
              <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-3">Resources</h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Skills Registry</a></li>
              <li><a href="#" className="hover:text-white transition-colors">API Reference</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-3">Connect</h3>
            <div className="flex items-center gap-3">
              <a href="#" className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 transition-colors" aria-label="GitHub">
                <Code2 className="w-5 h-5 text-zinc-400" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 transition-colors" aria-label="Social">
                <Sparkles className="w-5 h-5 text-zinc-400" />
              </a>
              <a href="#" className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 transition-colors" aria-label="Email">
                <Mail className="w-5 h-5 text-zinc-400" />
              </a>
            </div>
          </div>
        </div>
        <div className="pt-8 border-t border-zinc-800 text-center">
          <p className="text-sm text-zinc-500">
            Built with SMP v5.1 Protocol | framer-motion-animator | ui-ux-pro-max | 21st-dev-components | 21st-dev-builder-v2
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ──────────────────────────── MAIN PAGE ──────────────────────────── */

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-zinc-950">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Stats />
        <Features />
        <ComponentBrowser />
        <SkillsShowcase />
        <Pricing />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
